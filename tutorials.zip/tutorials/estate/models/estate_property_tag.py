from odoo import models, fields 

class EstatePropertyTag(models.Model):
    _name = "estate.property.tag"
    _description = "Property Tag"

    name = fields.Char(String="Tag Name",required=True)